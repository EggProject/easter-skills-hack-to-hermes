"""Patch site dataclasses + canonical site table for the S1.cap / Task E patcher.

TDD tests reference ``easter_hermes_sorry_skills._patcher_sites.Site`` /
``Anchor`` / ``S1_CAP_SITE`` / ``ALL_TASK_E_SITES`` / ``E*_SITE`` constants;
``_patcher_sites.py`` re-exports them so existing imports continue to work.

The site table is the spec-of-truth (plans/04 §Multi-signal targeting).
The two-line ``S1.cap`` is a SINGLE ``site_id``
with two anchors (``a`` + ``b``); both anchors must match for the site
to be considered patched (partial replacement is drift). Task E sites
are ADDITIVE-ONLY: the patcher inserts a single new line
immediately after the primary anchor; existing text is preserved verbatim.

Each :class:`Site` carries a ``line_for_state`` (the primary anchor's
1-based line) and a single :class:`Anchor`. The 8-char minimum anchor
length and the 1-based line number are the multi-signal targeting that
prevents accidental matches (plans/04 D5).

AC-2.8: the ``SKILL_CREATOR_CONSULT_RULE`` constant is no longer
defined in this plugin module. The canonical definition is written by
the E0 site into ``agent/prompt_builder.py`` (so the name is in scope
at module level for E1–E3 sites in the same file). E4 and E5 sites
(in ``agent/background_review.py``) reference the literal name and
rely on the E4b site, which writes a top-of-file
``from agent.prompt_builder import SKILL_CREATOR_CONSULT_RULE``
import line so the name resolves at runtime.

The text of the constant lives in :data:`_CONSULT_RULE_TEXT` and is
referenced by E0's ``insertion`` / ``expected_replacement`` so the
unit tests can still assert substring invariants against the patcher's
view of the value.

See also: plans/04-script-1-patch.md,
plans/10-toolchain-and-conventions.md.
"""

from __future__ import annotations

import dataclasses
from pathlib import Path

# --- file layout constants -----------------------------------------------
TOOLS_SKILL_UTILS_REL = Path("agent") / "skill_utils.py"
PROMPT_BUILDER_REL = Path("agent") / "prompt_builder.py"
BACKGROUND_REVIEW_REL = Path("agent") / "background_review.py"

# --- shared Task E constant text (written into agent/prompt_builder.py by E0).
# The plugin does NOT define a Python-level ``SKILL_CREATOR_CONSULT_RULE``
# binding: the constant lives in the TARGET file. The
# text below is the canonical wording that E0 inserts verbatim at the top
# of ``agent/prompt_builder.py``. AC-2.8 unit tests assert substring
# invariants against this string.
_CONSULT_RULE_TEXT = (
    "Use skill-creator for creating or editing skills; "
    "use skill_manage only when persisting skill state; "
    "for small targeted fixes, prefer patch-first when limited to one file, "
    "roughly under 20 lines, and no schema change."
)

# Top-of-file insertion (constant definition) for the E0 site. E0 anchors
# on the CLOSING ``"""`` line (L2) of the multi-line docstring at the
# top of ``agent/prompt_builder.py`` and appends this block immediately
# AFTER the closing ``"""`` so the constant lives at module scope.
# Append-before shape: the docstring's opening line (L1) and closing
# line (L2, the anchor) stay untouched; only lines after L2 receive
# the inserted constant.
_CONSULT_RULE_DEFINITION = f"\nSKILL_CREATOR_CONSULT_RULE = (\n    {_CONSULT_RULE_TEXT!r}\n)\n"

# --- site ``kind`` constants (WPS226 — reused > 3 times) -------------------
KIND_APPEND = "append"
KIND_CAP = "cap"

# Compact newline-literal aliases used by the Task E insertion strings.
# Extracted into named constants so wemake WPS342 (implicit raw string)
# does not flag the multi-`\n` patterns inside the Site() calls below.
_NL2 = r"\n\n"
# E4/E5 anchor blocks use EXPLICIT ``+`` between the implicit-concat
# fragments (instead of bare adjacency) so the patched file parses
# cleanly when the E4/E5 insertion lands between the first and
# second anchor lines (the patcher does ``lines.insert(idx + 1,
# insertion)``). With bare adjacency, the inserted expression breaks
# the implicit-concat and Python raises ``SyntaxError`` ("perhaps you
# forgot a comma?"). The explicit ``+`` keeps each fragment as a
# self-contained string-concat operand.
_E4_LINE_A = '    "session artifact. If the proposed name only makes sense for "\n'
_E4_LINE_B = '    "today' "'" "s task, it" "'" r's wrong — fall back to (1), (2), or (3).\n\n"' "\n"
_E4_LINE_C = '    "User-preference embedding (important): when the user expressed a "\n'
_E4_TEXT = _E4_LINE_A + _E4_LINE_B + _E4_LINE_C
_E5_LINE_A = '    "artifact. If the name only fits today\'s task, fall back to (1), "\n'
_E5_LINE_B = r'    "(2), or (3).\n\n"' "\n"
_E5_LINE_C = '    "User-preference embedding: when the user complains about how "\n'
_E5_TEXT = _E5_LINE_A + _E5_LINE_B + _E5_LINE_C


# --- site data classes ----------------------------------------------------


@dataclasses.dataclass(frozen=True)
class Anchor:
    """A single physical line that the patcher must locate exactly.

    ``line`` is 1-based; ``text`` is the byte-exact physical line
    content (no implicit-concat normalization, no whitespace scrubbing).
    """

    line: int
    text: str


@dataclasses.dataclass(frozen=True)
class Site:
    """A patch site.

    A site is identified by ``site_id`` and a list of :class:`Anchor`
    entries (1 anchor for an append-only Task E site, 2 anchors for
    the S1.cap atomic pair).

    ``kind`` is ``"cap"`` (replace pair) or ``"append"`` (additive Task
    E line, ADDITIVE-ONLY).

    ``file`` is the path RELATIVE to the --target root.

    ``expected_replacement`` is the verbatim text that, when present at
    the site, means the site is ALREADY patched (idempotency check).
    """

    site_id: str
    file_path: Path
    anchors: tuple[Anchor, ...]
    insertion: str
    expected_replacement: str
    kind: str = KIND_APPEND
    line_for_state: int = 0  # primary anchor line for sidecar / migration note

    def primary_anchor(self) -> Anchor:
        return self.anchors[0]


# --- canonical line-number constants (plans/04 §Multi-signal) -------------
S1_CAP_LINE_A = 716
S1_CAP_LINE_B = 717
# E0 anchors on the CLOSING ``"""`` of the multi-line docstring at
# the top of ``agent/prompt_builder.py``. Real Hermes's docstring
# spans L1 (opening) + L2 (blank) + L3..L4 (body) + L5 (closing),
# so the closing triple-double-quote lives at L5 — NOT L2. The
# patcher's anchor match is byte-exact (after splitlines() the
# closing line is the bare ``"""`` literal), so the anchor text
# matches the real closing line and only the line number had to
# drift from 2 -> 5 to follow the real upstream layout.
E0_LINE = 5
# AC-2.8: E1/E2 anchor lines follow the real Hermes
# ``prompt_builder.py`` layout for commit 30e947e0a. The E0 insertion
# (constant definition) is applied LAST (the patcher sorts sites in
# DESCENDING line_for_state order), so the original E1/E2 anchors remain
# valid against the pre-E0 file state.
E1_LINE = 182
E2_LINE = 161
# E4b anchors on the ``from __future__ import annotations`` line at
# L19 of ``agent/background_review.py`` (NOT the L17 closing
# triple-double-quote). Real Hermes's docstring spans L1 (opening)
# + L2 (blank) + L3..L16 (body) + L17 (closing) + L18 (blank) +
# L19 (``from __future__ import annotations``). PEP 563 requires
# ``from __future__ import annotations`` to be the FIRST non-docstring
# statement at module scope — preceding it with any other import
# statement raises ``SyntaxError`` at compile time (``ast.parse`` is
# lenient and accepts the broken ordering, but real CPython refuses).
# Anchoring on L17 docstring closer pushed the E4b insertion to L18
# (the new import), demoting ``from __future__`` to L20 and breaking
# PEP 563. Anchoring on the byte-exact L19 line preserves PEP 563
# ordering: the patcher inserts AFTER L19, so the import lands at L20
# and ``from __future__`` stays the first module-scope statement.
E4B_LINE = 19
# Same descending-order logic for E4/E5 in ``agent/background_review.py``
# (E4b applies last, so the E4/E5 anchors remain valid against the
# pre-E4b file state). The anchor lines follow the real Hermes commit
# 30e947e0a layout.
E4_LINE = 230
E5_LINE = 317

# Top-of-file anchor lines for E0 (agent/prompt_builder.py) and E4b
# (agent/background_review.py). Both anchor on the CLOSING ``"""``
# line of a multi-line docstring; the patcher inserts the payload
# (constant / import) immediately after the closing line so the
# code lands at module scope. The canonical anchor text below
# mirrors the test fixtures in ``tests/conftest.py`` and the real
# upstream hermes closing lines (byte-exact after ``splitlines()``
# strips the trailing newline: each closing line is the bare
# ``"""`` literal). A drifted closing line is detected and the
# site TEXT_DRIFTs and aborts so the operator can review.
_E0_ANCHOR_TEXT = '"""'
# E4b anchors on the ``from __future__ import annotations`` line
# (PEP 563 ordering). The canonical anchor text mirrors the real
# upstream hermes L19 line in ``agent/background_review.py``
# (byte-exact after ``splitlines()`` strips the trailing newline:
# the line is the literal ``from __future__ import annotations``
# string). Anchoring on this byte-exact line preserves PEP 563
# ordering: the E4b insertion lands AFTER the anchor at L20, leaving
# ``from __future__ import annotations`` at L19 (the first module-
# scope statement). The conftest fixture
# ``_build_background_review_padded`` mirrors this layout exactly
# (L19 = ``from __future__ import annotations\n``).
_E4B_ANCHOR_TEXT = "from __future__ import annotations\n"

# --- the S1.cap site (two-anchor atomic pair) -----------------------------

_FALLBACK_MAX_DESCRIPTION_LENGTH = 1024
S1_CAP_SITE = Site(
    site_id="S1.cap",
    file_path=TOOLS_SKILL_UTILS_REL,
    anchors=(
        Anchor(line=S1_CAP_LINE_A, text="    if len(desc) > 60:"),
        Anchor(line=S1_CAP_LINE_B, text='        return desc[:57] + "..."'),
    ),
    insertion=(
        f"    _MAX_DESCRIPTION_LENGTH = {_FALLBACK_MAX_DESCRIPTION_LENGTH}\n"
        "    if len(desc) > _MAX_DESCRIPTION_LENGTH:\n"
        '        return desc[:_MAX_DESCRIPTION_LENGTH - 3] + "..."\n'
    ),
    # The idempotency check looks for the replacement text:
    expected_replacement=(
        f"    _MAX_DESCRIPTION_LENGTH = {_FALLBACK_MAX_DESCRIPTION_LENGTH}\n"
        "    if len(desc) > _MAX_DESCRIPTION_LENGTH:\n"
        '        return desc[:_MAX_DESCRIPTION_LENGTH - 3] + "..."\n'
    ),
    kind=KIND_CAP,
    line_for_state=S1_CAP_LINE_A,
)

# AC-2.11 fallback: retained as a compatibility site for callers that
# inspect the circular-import branch explicitly. It now matches S1.cap's
# import-free local constant shape, because the pinned Hermes
# ``agent/skill_utils.py`` module intentionally avoids tools-layer imports.
S1_CAP_SITE_FALLBACK = Site(
    site_id="S1.cap_fallback",
    file_path=TOOLS_SKILL_UTILS_REL,
    anchors=(
        Anchor(line=S1_CAP_LINE_A, text="    if len(desc) > 60:"),
        Anchor(line=S1_CAP_LINE_B, text='        return desc[:57] + "..."'),
    ),
    insertion=(
        f"    _MAX_DESCRIPTION_LENGTH = {_FALLBACK_MAX_DESCRIPTION_LENGTH}\n"
        "    if len(desc) > _MAX_DESCRIPTION_LENGTH:\n"
        '        return desc[:_MAX_DESCRIPTION_LENGTH - 3] + "..."\n'
    ),
    expected_replacement=(
        f"    _MAX_DESCRIPTION_LENGTH = {_FALLBACK_MAX_DESCRIPTION_LENGTH}\n"
        "    if len(desc) > _MAX_DESCRIPTION_LENGTH:\n"
        '        return desc[:_MAX_DESCRIPTION_LENGTH - 3] + "..."\n'
    ),
    kind=KIND_CAP,
    line_for_state=S1_CAP_LINE_A,
)


# --- the 6 Task E sites ---------------------------------------------------

# E0 inserts the SKILL_CREATOR_CONSULT_RULE constant definition near the
# top of agent/prompt_builder.py (immediately after the L5 closing
# ``"""`` line of the real multi-line docstring). This is the single source
# of truth for the constant's wording; E1-E3 reference the literal name
# SKILL_CREATOR_CONSULT_RULE which resolves at module level once E0
# has been applied. The patcher applies sites in DESCENDING line order
# so E0 (L5) runs last and its insertion doesn't shift higher-line
# anchors.
E0_CONSULT_RULE_DEF = Site(
    site_id="E0.consult_rule_def",
    file_path=PROMPT_BUILDER_REL,
    anchors=(Anchor(line=E0_LINE, text=_E0_ANCHOR_TEXT),),
    insertion=_CONSULT_RULE_DEFINITION,
    # Idempotency: the constant definition is present iff the marker
    # assignment line appears verbatim after the L5 anchor.
    expected_replacement="SKILL_CREATOR_CONSULT_RULE = (",
    kind=KIND_APPEND,
    line_for_state=E0_LINE,
)

# E4b inserts the import of SKILL_CREATOR_CONSULT_RULE from
# agent.prompt_builder into agent/background_review.py so the E4 and
# E5 sites can use the constant name (the name resolves via the import
# at runtime). The anchor is the byte-exact L19
# ``from __future__ import annotations`` line; the import is appended
# AFTER it so PEP 563 ordering remains valid.
E4B_CONSULT_RULE_IMPORT = Site(
    site_id="E4b.consult_rule_import",
    file_path=BACKGROUND_REVIEW_REL,
    anchors=(Anchor(line=E4B_LINE, text=_E4B_ANCHOR_TEXT),),
    insertion="from agent.prompt_builder import SKILL_CREATOR_CONSULT_RULE\n",
    expected_replacement="from agent.prompt_builder import SKILL_CREATOR_CONSULT_RULE",
    kind=KIND_APPEND,
    line_for_state=E4B_LINE,
)

E1_SKILLS_GUIDANCE = Site(
    site_id="E1.skills_guidance",
    file_path=PROMPT_BUILDER_REL,
    anchors=(
        Anchor(
            line=E1_LINE,
            text='    "Skills that aren\'t maintained become liabilities."',
        ),
    ),
    # E1 is appended inside a parenthesized implicit-concat; the next
    # line is ")" closing the constant. We append ONE line that begins
    # with a single leading space, concatenating to the previous literal.
    insertion=r'    " " + SKILL_CREATOR_CONSULT_RULE' "\n",
    # Idempotency: the site is patched iff the appended line is present
    # verbatim after the L182 anchor.
    expected_replacement=r'    " " + SKILL_CREATOR_CONSULT_RULE',
    kind=KIND_APPEND,
    line_for_state=E1_LINE,
)

E2_MEMORY_GUIDANCE = Site(
    site_id="E2.memory_guidance",
    file_path=PROMPT_BUILDER_REL,
    anchors=(
        Anchor(
            line=E2_LINE,
            text=r'    "necessary later, save it as a skill with the skill tool.\n"',
        ),
    ),
    insertion=r'    " " + SKILL_CREATOR_CONSULT_RULE + "\n"' "\n",
    expected_replacement=r'    " " + SKILL_CREATOR_CONSULT_RULE + "\n"',
    kind=KIND_APPEND,
    line_for_state=E2_LINE,
)

E4_SKILL_REVIEW_PROMPT = Site(
    site_id="E4.skill_review_prompt_opt4",
    file_path=BACKGROUND_REVIEW_REL,
    anchors=(
        Anchor(
            line=E4_LINE,
            text=_E4_TEXT,
        ),
    ),
    # E4/E5 insert a SINGLE source line that begins with ``+ ``
    # (explicit concat operator) so the patched tuple body parses
    # cleanly with the multi-line anchor block. The line ends with a
    # LITERAL ``'\n\n'`` Python string literal; the ``!r`` is
    # load-bearing: without it the f-string inlines actual newlines
    # and the insertion spans 3 source lines, breaking the layout
    # asserted by ``test_e4_skill_review_prompt_appends_only`` and
    # ``test_e5_combined_review_prompt_appends_only``. The ``+``
    # prefix is required because the anchor block uses explicit
    # ``+`` between string fragments (not bare adjacency), so the
    # inserted expression must also start with ``+`` to chain.
    insertion=f"    + (SKILL_CREATOR_CONSULT_RULE + {_NL2!r}) +\n",
    expected_replacement=f"    + (SKILL_CREATOR_CONSULT_RULE + {_NL2!r}) +",
    kind=KIND_APPEND,
    line_for_state=E4_LINE,
)

E5_COMBINED_REVIEW_PROMPT = Site(
    site_id="E5.combined_review_prompt_opt4",
    file_path=BACKGROUND_REVIEW_REL,
    anchors=(
        Anchor(
            line=E5_LINE,
            text=_E5_TEXT,
        ),
    ),
    insertion=f"    + (SKILL_CREATOR_CONSULT_RULE + {_NL2!r}) +\n",
    expected_replacement=f"    + (SKILL_CREATOR_CONSULT_RULE + {_NL2!r}) +",
    kind=KIND_APPEND,
    line_for_state=E5_LINE,
)

ALL_TASK_E_SITES: tuple[Site, ...] = (
    E0_CONSULT_RULE_DEF,
    E1_SKILLS_GUIDANCE,
    E2_MEMORY_GUIDANCE,
    E4B_CONSULT_RULE_IMPORT,
    E4_SKILL_REVIEW_PROMPT,
    E5_COMBINED_REVIEW_PROMPT,
)
